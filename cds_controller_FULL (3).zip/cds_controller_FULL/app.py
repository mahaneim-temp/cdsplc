
from flask import Flask, render_template, request, jsonify
import time

app = Flask(__name__)

state = {
    "mode": "MODE1",
    "step": "IDLE",
    "preset": "MIXED",
    "elapsed": 0,
    "elapsed_str": "00:00",
    "t1": 25.0,
    "stack": 25.0,
    "fan1": 0,
    "fan2": 0,
    "p1": False,
    "p2": False,
    "p3": False,
    "ign": False,
    "quench": False,
    "bin_horizontal": "OUT",
    "bin_vertical": "DOWN",
    "alarm": "정상",
    "camera": "chamber"
}

last_tick = time.time()

def tick():
    global last_tick
    now = time.time()
    dt = now - last_tick
    last_tick = now
    
    # 경과시간
    state["elapsed"] += dt
    m = int(state["elapsed"] // 60)
    s = int(state["elapsed"] % 60)
    state["elapsed_str"] = f"{m:02d}:{s:02d}"

    # 온도 시뮬레이션 (아주 단순 모델)
    heat = 0
    if state["p1"] or state["p2"] or state["p3"]:
        heat += 1.5
    heat += (state["fan1"] / 100) * 0.4
    
    cool = (state["fan2"] / 100) * 0.3
    if state["quench"]:
        cool += 2.5

    state["t1"] += (heat - cool) * dt
    state["stack"] += ((state["t1"] - state["stack"]) * 0.02)

    # 하한
    state["t1"] = max(20, state["t1"])
    state["stack"] = max(20, state["stack"])

    # 자동 단계 변화 (시연용)
    if state["step"] == "S2_PURGE":
        state["fan1"] = 20
        state["fan2"] = 20
        if state["elapsed"] > 15: state["step"] = "S3_IGNITION"

    elif state["step"] == "S3_IGNITION":
        state["p1"] = state["p2"] = state["p3"] = True
        state["ign"] = True
        state["fan1"] = 60
        state["fan2"] = 60
        if state["t1"] > 200:
            state["ign"] = False
            state["step"] = "S4_BURN"

    elif state["step"] == "S4_BURN":
        if state["t1"] > 600:
            state["p1"] = state["p2"] = state["p3"] = False
            state["step"] = "S5_END_BURN"

    elif state["step"] == "S5_END_BURN":
        state["fan1"] = 20
        state["fan2"] = 80

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/api/status")
def api_status():
    tick()
    return jsonify(state)

@app.route("/api/command", methods=["POST"])
def api_command():
    data = request.json or {}
    cmd = data.get("cmd")
    val = data.get("value")

    if cmd == "AUTO_START":
        state["elapsed"] = 0
        state["step"] = "S2_PURGE"

    if cmd == "STOP":
        state["step"] = "IDLE"
        state["fan1"] = state["fan2"] = 0
        state["p1"] = state["p2"] = state["p3"] = False
        state["ign"] = False

    if cmd == "SET_FAN1": state["fan1"] = int(val)
    if cmd == "SET_FAN2": state["fan2"] = int(val)

    if cmd == "TOGGLE_P1": state["p1"] = not state["p1"]
    if cmd == "TOGGLE_P2": state["p2"] = not state["p2"]
    if cmd == "TOGGLE_P3": state["p3"] = not state["p3"]
    if cmd == "IGNITION":  state["ign"] = not state["ign"]

    if cmd == "BIN_IN": state["bin_horizontal"] = "IN"
    if cmd == "BIN_OUT": state["bin_horizontal"] = "OUT"
    if cmd == "BIN_UP": state["bin_vertical"] = "UP"
    if cmd == "BIN_DOWN": state["bin_vertical"] = "DOWN"

    if cmd == "SET_CAMERA": state["camera"] = val

    return jsonify({"ok":True})

if __name__ == "__main__":
    app.run(port=5000, debug=False)

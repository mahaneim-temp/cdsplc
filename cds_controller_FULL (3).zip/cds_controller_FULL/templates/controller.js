// controller.js
// 소각로 UI 동작 스크립트

// ----------------------
// 공통: 유틸 & 로그 출력
// ----------------------
const logArea = document.getElementById("log-area");

function formatTime(date) {
  const h = String(date.getHours()).padStart(2, "0");
  const m = String(date.getMinutes()).padStart(2, "0");
  const s = String(date.getSeconds()).padStart(2, "0");
  return `${h}:${m}:${s}`;
}

function addLog(message) {
  if (!logArea) return;

  const now = new Date();
  const line = document.createElement("div");
  line.className = "log-line";
  line.textContent = `[${formatTime(now)}] ${message}`;

  logArea.appendChild(line);

  // 너무 많이 쌓이지 않게 200줄만 유지
  const maxLines = 200;
  while (logArea.children.length > maxLines) {
    logArea.removeChild(logArea.firstChild);
  }

  // 항상 맨 아래로 스크롤
  logArea.scrollTop = logArea.scrollHeight;
}

// ----------------------
// 1. 운전 모드: AUTO START / STOP + 경과시간
// ----------------------
const stepText = document.getElementById("step-text");
const elapsedText = document.getElementById("elapsed-time");
const btnAutoStart = document.getElementById("btn-auto-start");
const btnStop = document.getElementById("btn-stop");

let elapsedSeconds = 0;
let timerId = null;

function updateElapsedLabel() {
  const m = String(Math.floor(elapsedSeconds / 60)).padStart(2, "0");
  const s = String(elapsedSeconds % 60).padStart(2, "0");
  if (elapsedText) {
    elapsedText.textContent = `${m}:${s}`;
  }
}

function startRun() {
  if (timerId !== null) return; // 이미 RUN 중

  elapsedSeconds = 0;
  updateElapsedLabel();

  if (stepText) stepText.textContent = "RUN";

  timerId = window.setInterval(() => {
    elapsedSeconds += 1;
    updateElapsedLabel();
  }, 1000);

  addLog("AUTO START 실행");
}

function stopRun(reason = "STOP 버튼") {
  if (timerId !== null) {
    clearInterval(timerId);
    timerId = null;
  }
  if (stepText) stepText.textContent = "IDLE";
  addLog(`${reason} - 운전 정지`);
}

if (btnAutoStart) {
  btnAutoStart.addEventListener("click", () => {
    startRun();
  });
}

if (btnStop) {
  btnStop.addEventListener("click", () => {
    stopRun("STOP 버튼");
  });
}

// ----------------------
// 2. EMG 버튼
// ----------------------
const emgCard = document.querySelector(".emg-card");

if (emgCard) {
  emgCard.addEventListener("click", () => {
    // 긴급 정지: 타이머 정지 + STEP IDLE
    stopRun("EMG 동작");
    emgCard.classList.add("active");
    addLog("EMG 동작 (긴급 정지)");
    // 1초 뒤 하이라이트 해제
    setTimeout(() => emgCard.classList.remove("active"), 1000);
  });
}

// ----------------------
// 3. IGN / PUMP / P1 / P2 / P3 토글
// ----------------------
const deviceConfig = [
  { id: "btn-ign",   label: "IGN" },
  { id: "btn-pump",  label: "PUMP" },
  { id: "btn-p1",    label: "P1" },
  { id: "btn-p2",    label: "P2" },
  { id: "btn-p3",    label: "P3" },
];

const deviceState = {};

deviceConfig.forEach(({ id, label }) => {
  const btn = document.getElementById(id);
  if (!btn) return;

  const stateSpan = btn.querySelector(".device-state");

  // 초기 상태: OFF
  deviceState[id] = false;

  btn.addEventListener("click", () => {
    deviceState[id] = !deviceState[id]; // 토글
    const isOn = deviceState[id];

    btn.classList.toggle("on", isOn);
    btn.classList.toggle("off", !isOn);   // ← OFF 상태 클래스도 같이 관리
    if (stateSpan) stateSpan.textContent = isOn ? "ON" : "OFF";

    addLog(`${label} 출력 ${isOn ? "ON" : "OFF"}`);
  });
});

// ----------------------
// 4. 카메라 탭 전환
// ----------------------
const camTabs = document.querySelectorAll(".cam-tab");

camTabs.forEach((tab, index) => {
  tab.addEventListener("click", () => {
    camTabs.forEach(t => t.classList.remove("active"));
    tab.classList.add("active");
    addLog(`카메라${index + 1} 선택`);
    // 실제 영상 소스 전환은 여기에서 연동
  });
});

// ----------------------
// 5. 폐기물통 이동 버튼 (로그만 남김)
// ----------------------
const binButtons = [
  { id: "btn-bin-out",  label: "폐기물통 수평 OUT" },
  { id: "btn-bin-in",   label: "폐기물통 수평 IN" },
  { id: "btn-bin-down", label: "폐기물통 수직 DOWN" },
  { id: "btn-bin-up",   label: "폐기물통 수직 UP" },
];

binButtons.forEach(({ id, label }) => {
  const btn = document.getElementById(id);
  if (!btn) return;
  btn.addEventListener("click", () => addLog(label));
});

// ----------------------
// 6. FAN 속도 슬라이더 → % 표시 (시각 효과)
// ----------------------
const fan1Gauge = document.getElementById("fan1-gauge");
const fan2Gauge = document.getElementById("fan2-gauge");
const fan1Percent = document.getElementById("fan1-percent");
const fan2Percent = document.getElementById("fan2-percent");

function updateFanPercent(gauge, labelEl) {
  if (!gauge || !labelEl) return;
  const value = Number(gauge.dataset.value || "55"); // data-value 사용
  labelEl.textContent = `${value}%`;
}

// 시작 시 한 번 표시
updateFanPercent(fan1Gauge, fan1Percent);
updateFanPercent(fan2Gauge, fan2Percent);

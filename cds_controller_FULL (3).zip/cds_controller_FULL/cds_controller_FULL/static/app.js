
function send(cmd,val=null){
fetch("/api/command",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({cmd:cmd,value:val})})
}
function setFan(n){
let v=document.getElementById("fan"+n).value;
send(n==1?"SET_FAN1":"SET_FAN2",v);
}
function cam(c){send("SET_CAMERA",c);}
async function loop(){
let r=await fetch("/api/status");
let s=await r.json();
document.getElementById("t1").innerText=s.t1.toFixed(1)+" C";
document.getElementById("stack").innerText=s.stack.toFixed(1)+" C";
document.getElementById("step").innerText=s.step;
document.getElementById("fan1").value=s.fan1;
document.getElementById("fan2").value=s.fan2;
document.getElementById("camera").innerText="CAMERA : "+s.camera;
}
setInterval(loop,500);
